# blooket-cheats
Blooket Hacks/Cheats (** SUPER EASY TO USE **)

# support/help
These are just some cheats you can use in **blooket** not in games unless you use correct answer one.
I will make a discord server for this soon. For now use bookmarklet method or just use the search bar.
